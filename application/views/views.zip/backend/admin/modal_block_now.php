<input type="hidden" value="<?php echo $param2 ?>" name="user_id">
<h3> Are sure you want to deactivate this service, be reminded that services are linked to user accounts</h3>