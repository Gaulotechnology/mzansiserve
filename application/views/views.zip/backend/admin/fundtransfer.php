
<div class="container col-md-12">
	<div class="row">
		<div class="shop-product">
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="row">
						<div class="col-md-4"><b class="btn btn-warning btn-block">Share your Balance with Other User</b></div>
						<div class="col-md-4"><b class="btn btn-info  btn-block">Shared Balance Will Added to Account Balance</b></div>
						<div class="col-md-4"><b class="btn btn-primary  btn-block">Minimum 01 EUR Can be Transferred</b></div>
					</div>
				</div>
			</div>
		</div>
	<div class="row">
		<form action="" method="post">
			<div class="col-md-12 product-service md-margin-bottom-30">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<input class="form-control input-lg" placeholder="USERNAME to Transfer" name="user" id="refname" type="text" required="">
								</div>
							</div>
							<div class="col-md-6">
								<div id="resu"></div>
							</div>
						</div>
						<div class="form-group">
<div class="input-group">
<span class="input-group-addon">TRANSFER</span>
<input class="form-control input-lg" placeholder="AMOUNT YOU WANT TO SHARE" name="amount" type="text" required="">
<span class="input-group-addon">EUR</span>
</div>
<br>
<div class="form-group">
<input class="form-control input-lg" placeholder="Transection PIN" name="trxp" type="password" required="">
</div>
<p style="color:red; font-weight: bold; font-size:20px;"> 3% Transfer Charge will Applied and transferred Fund will go to Secondary Balance.</p>

</div>
</div>
<div class="col-md-12">
<button type="submit" class="btn btn-success btn-block"> Transfer Now</button>
</div>
</div>
</div>
</form>
</div>
</div>

</div>
</div>










