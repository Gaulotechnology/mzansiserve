




<div class="panel panel-default">
<div class="panel-heading"> <h1>Request For Withdraw</h1></div>
<div class="panel-body">

<div class="row">


<form action="" method="post">
<div class="col-md-12 product-service md-margin-bottom-30">

<div class="form-group">
<div class="input-group">
<span class="input-group-addon">WITHDRAW</span>
<input class="form-control input-lg" placeholder="AMOUNT YOU WANT TO WITHDRAW | Minimum 10 EUR | You Have 1416 EUR" name="amount" type="text" required="">
<span class="input-group-addon">EUR</span>
</div>
</div>





<div class="form-group">
<input class="form-control input-lg" placeholder="WITHDRAW METHOD | eg: PayPal, Bank" name="method" type="text" required="">
</div>

<div class="form-group">
<textarea name="details" class="form-control input-lg" placeholder="Where Your Money Will Go? PayPal ID or Bank Account Details" rows="3" required=""></textarea>
</div>



<div class="form-group">
<input class="form-control input-lg" placeholder="Transection PIN" name="trxp" type="password" required="">
</div>







<p style="color:red; font-weight: bold; font-size:20px;"> 10% Withdraw Charge will Applied and need ADMIN aproval for this.</p>



<button type="submit" class="btn btn-success btn-block"> Request For Withdraw Now</button>


</div>
</div>




</form>


</div>
</div></div>



