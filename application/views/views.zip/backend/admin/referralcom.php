
<!--=== Registre ===-->
<div style="margin-top:30px;">
<div class="container col-md-12">
<div class="row">








<div class="col-md-12">


<!-- BEGIN EXAMPLE TABLE PORTLET-->
<div class="portlet light bordered">
<div class="portlet-title">
<div class="caption font-dark">
<span class="caption-subject bold uppercase"> Referral Commission</span>
</div>
<div class="tool"> </div>
</div>
<div class="portlet-body">
<table class="table table-striped table-bordered table-hover" id="sample_1">
<thead>



<tr>
<th> SL# </th>
<th> Amount </th>
<th> Description </th>
<th> Time </th>
</tr>

</thead><tbody>

                                
<tr>

<td>0001</td>
<td><b class='btn btn-success btn-xs'> 10 EUR </b></td>
<td>Referral Commision From tlrtlr</td>
<td>2016-12-31 02:14:25</td>






</tr>                                
<tr>

<td>0002</td>
<td><b class='btn btn-success btn-xs'> 90 EUR </b></td>
<td>Deposit Commision From abirkhan75</td>
<td>2016-10-05 01:19:25</td>






</tr>                                
<tr>

<td>0003</td>
<td><b class='btn btn-success btn-xs'> 10 EUR </b></td>
<td>Deposit Commision From abirkhan75</td>
<td>2016-10-05 01:19:15</td>






</tr>                                
<tr>

<td>0004</td>
<td><b class='btn btn-success btn-xs'> 10 EUR </b></td>
<td>Deposit Commision From abirkhan75</td>
<td>2016-10-05 01:18:34</td>






</tr>                                           
                                       

</tbody>
</table>
</div>
</div>
<!-- END EXAMPLE TABLE PORTLET-->

</div>



















<div style="margin-top:100px;"></div>




</div><!--/end row-->
</div><!--/end container-->
</div>
<!--=== End Registre ===-->