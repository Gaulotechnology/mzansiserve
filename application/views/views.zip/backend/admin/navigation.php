<div class="sidebar-menu">
    <header class="logo-env" >

        <!-- logo -->
        <div class="logo" style="">
            <a href="<?php echo base_url('page/dashboard'); ?>">
            <?php if($role==ROLE_ADMIN){ ?>
                <img src="<?php echo base_url() ?>assets/images/logo.png"  style="max-width:90%;max-height:60px;"/>
            <?php }else{ ?>
                <img src="<?php echo base_url() ?>assets/images/logo.png"  style="max-width:90%;max-height:60px;"/>
            <?php } ?>                   
            </a>
            <?php if($role==ROLE_EMPLOYEE) {
                ?><div><h4>Balance: R600.00</h4></div> <?php
            } ?>
        </div>

        <!-- logo collapse icon -->
        <div class="sidebar-collapse" style="">
            <a href="#" class="sidebar-collapse-icon with-animation">

                <i class="entypo-menu"></i>
            </a>
        </div>

        <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
        <div class="sidebar-mobile-menu visible-xs">
            <a href="#" class="with-animation">
                <i class="entypo-menu"></i>
            </a>
        </div>
    </header>

    <div style=""></div>	
    <ul id="main-menu" class="">
        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->


        <!-- DASHBOARD -->
        <li class="<?php if ($page_name == 'dashboard') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/dashboard">
                <i class="fa fa-dashboard"></i>
                <span><?php echo "Dashboard" ?></span>
            </a>
        </li>

        <!-- NOTICEBOARD -->
        

       

        <!-- NOTICEBOARD -->
       
        <!-- SETTINGS -->
        <?php
        if($role==ROLE_ADMIN){
            ?>
 <li class="<?php
        if ($page_name == 'manage_accounts'
                   )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_accounts">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "manage accounts"; ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'activation_pending') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/activation_pending">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "activation pending"; ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'activated_accounts') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/activated_accounts">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "activated accounts"; ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'blocked_accounts') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/blocked_accounts">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "blocked accounts"; ?></span>
                    </a>
                </li>
        
      
            </ul>
        </li>
    
            <li class="<?php
        if ($page_name == 'service_categories'
                   )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/service_categories">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "service categories"; ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'service_categories') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/service_categories/2">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "professional services"; ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'service_categories') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/service_categories/3">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "service providers"; ?></span>
                    </a>
                </li>
        
      
            </ul>
        </li>
               <li class="<?php
        if ($page_name == 'system_settings' ||
                $page_name == 'manage_language'
                   )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/car_radius">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "cartypes & radius"; ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'system_settings') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/system_settings">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "manage car radius"; ?></span>
                    </a>
                </li>
        
      
            </ul>
        </li>
        <li class="<?php
        if ( $page_name == 'page/manage_price'
                   )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_price">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "manage prices"; ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'system_settings') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/system_settings">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "modify prices"; ?></span>
                    </a>
                </li>
        
      
            </ul>
        </li>
        <li class="<?php
        if ( $page_name == 'page/manage_numbers'
                   )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_price">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "phone numbers"; ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'system_settings') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/system_settings">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "manage phone numbers"; ?></span>
                    </a>
                </li>
        
      
            </ul>
        </li>
            
        <li class="<?php
        if ($page_name == 'system_settings' ||
                $page_name == 'manage_language' ||
                $page_name == 'manage_cities'   ||
                $page_name == 'manage_regions'
                
                   )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/system_settings">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo get_phrase('settings'); ?></span>
            </a>
            <ul>

            <li class="<?php if ($page_name == 'manage_cities') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/manage_cities">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "Manage Cities" ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'manage_regions') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/manage_regions">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo "Manage Regions" ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'system_settings') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/system_settings">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo get_phrase('general_settings'); ?></span>
                    </a>
                </li>
        
                <li class="<?php if ($page_name == 'manage_language') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/manage_language">
                        <span><i class="fa fa-chevron-circle-down"></i> <?php echo get_phrase('language_settings'); ?></span>
                    </a>
                </li>
      
            </ul>
        </li>
        <?php } ?>
        <?php
        if($role==ROLE_PROVIDER ){
            ?>
<!-- SERVICES -->
<li class="<?php
        if ($page_name == 'manage_service' )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_service">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "My Services"; ?></span>
            </a>
            <ul>
   
        <li class="<?php if ($page_name == 'manage_services') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/manage_service">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "manage services"; ?></span>
            </a>
        </li>
       
        </ul>
        </li>
        <?php } ?>



       <?php if($role==ROLE_PROFESSIONAL){
            ?>
<!-- SERVICES -->
<li class="<?php
        if ($page_name == 'manage_profession' )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_profession">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "My Services"; ?></span>
            </a>
            <ul>
   
        <li class="<?php if ($page_name == 'manage_profession') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/manage_profession">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "manage services"; ?></span>
            </a>
        </li>
       
        </ul>
        </li>
        <?php } ?>

        <?php
        if($role==ROLE_DRIVER){
            ?>
<!-- CARS -->
<li class="<?php
        if ($page_name == 'manage_vehicles' )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_vehicles">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "My Cars"; ?></span>
            </a>
            <ul>
   
        <li class="<?php if ($page_name == 'manage_cars') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/manage_cars">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "manage cars"; ?></span>
            </a>
        </li>
       
        </ul>
        </li>
        <?php } ?>
<!-- STUDENT -->
<li class="<?php
        if ($page_name == 'categories' ||
                $page_name == 'products' ||
                $page_name == 'recurring' ||
                $page_name == 'filters' ||
                $page_name == 'attributes' ||
                $page_name == 'options' ||
                $page_name == 'manufacturers' ||
                $page_name == 'downloads' ||
                $page_name == 'reviews' ||
                $page_name == 'attribute_groups' ||
                $page_name == 'information')
            echo 'opened active has-sub';
        ?> ">
            <a href="#">
                <i class="fa fa-tags"></i>
                <span><?php echo "Catalog";//get_phrase('student'); ?></span>
            </a>
            <ul>
                <li class="<?php if ($page_name == 'categories') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>page/category">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Categories"; ?></span>
                    </a>
                </li>
                <li class="<?php if ($page_name == 'product') echo 'active'; ?> ">
                <a href="<?php echo base_url(); ?>page/product">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Products"; ?></span>
                    </a>
                </li>

                <li class="<?php if ($page_name == 'recurring') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/recurring">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Recurring Profiles"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'filters') echo 'active'; ?> ">
                    <a href="<?php echo base_url(); ?>page/filters">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Filters"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'attributes') echo 'opened active'; ?> ">
                <a href="#">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Attributes"; ?></span>
                    </a>
                    <ul>
                    <li class="<?php if ($page_name == 'attributes') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/attributes">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Attributes"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'attribute_groups') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/attribute_groups">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Attribute groups"; ?></span>
                    </a>
                    
                </li>
                    </ul>
                </li>
                <li class="<?php if ($page_name == 'options') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/options">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Options"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'manufacturers') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/manufacturers">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Manufacturers"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'reviews') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/reviews">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Reviews"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'downloads') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/downloads">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Downloads"; ?></span>
                    </a>
                    
                </li>
                <li class="<?php if ($page_name == 'information') echo 'opened active'; ?> ">
                <a href="<?php echo base_url(); ?>page/information">
                        <span><i class="fa fa-angle-double-right"></i> <?php echo "Information"; ?></span>
                    </a>
                    
                </li>

            </ul>
        </li>
        
<!-- PAYMENT -->
        

<li class="<?php
        if ($page_name == 'manage_cards' )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/manage_cards">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "Payment"; ?></span>
            </a>
            <ul>
   
        <li class="<?php if ($page_name == 'manage_cards') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/manage_cards">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "My Cards" ?></span>
            </a>
        </li>
        <li class="<?php if ($page_name == 'noticeboard' || $page_name == 'transaction_history') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/transaction_history">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "transaction history"; ?></span>
            </a>
        </li>
        </ul>
        </li>

        <!-- MY WALLET -->
        

<li class="<?php
        if ($page_name == 'transaction_history' )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/transaction_history">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "My Wallet"; ?></span>
            </a>
            <ul>
   
        <li class="<?php if ($page_name == 'transaction_history') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/transaction_history">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "Account Balance" ?></span>
            </a>
        </li>
        
        </ul>
        </li>
<!-- NOTICEBOARD -->
        

<li class="<?php
        if ($page_name == 'noticeboard' )
                        echo 'opened active';
        ?> ">
            <a href="<?php echo base_url(); ?>page/noticeboard">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "Noticeboard"; ?></span>
            </a>
            <ul>
   
        <li class="<?php if ($page_name == 'noticeboard') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/noticeboard">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo get_phrase('noticeboard'); ?></span>
            </a>
        </li>
        <li class="<?php if ($page_name == 'noticeboard') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/noticeboard">
                <i class="fa  fa-chevron-circle-down"></i>
                <span><?php echo "push notifications and url"; ?></span>
            </a>
        </li>
        </ul>
        </li>

<!-- ACCOUNT -->
<li class="<?php
        if ($page_name == 'multistep_registration')
                        echo 'opened active';
        ?> ">
        <a href="<?php echo base_url(); ?>page/multistep_registration">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "My Profile"; ?></span>
            </a>
            <ul>
        <li class="<?php if ($page_name == 'multistep_registration') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/multistep_registration">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "Registration details"; ?></span>
            </a>
        </li>
        <li class="<?php if ($page_name == 'change_password') echo 'active'; ?> ">
            <a href="<?php echo base_url(); ?>page/change_password">
                <i class="fa fa-chevron-circle-down"></i>
                <span><?php echo "Change Password"; ?></span>
            </a>
        </li>

    </ul>
        </li>
    

</div>