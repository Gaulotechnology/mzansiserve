
<!--=== Registre ===-->
<div style="margin-top:30px;">
<div class="container col-md-12">
<div class="row">

<div class="col-md-8 col-md-offset-2 col-sm-12">
<div class="panel panel-primary">
<div class="panel-heading"> <h1 style="color:#fff;">Your Current BV</h1></div>
<div class="panel-body">
<div class="row">
<div class="col-md-6">
<b class="btn btn-success btn-block btn-lg"> LEFT SIDE <br>0</b>
</div>	
<div class="col-md-6">
<b class="btn btn-info btn-block btn-lg"> RIGHT SIDE <br>0</b>
</div>	
</div>
</div>
</div><div style="margin-top:60px;"></div>
</div>


<div class="col-md-8 col-md-offset-2 col-sm-12">
<div class="panel panel-primary">
<div class="panel-heading"> <h1 style="color:#fff;"> PAID Member On Your Tree</h1></div>
<div class="panel-body">
<div class="row">
<div class="col-md-6">
<b class="btn btn-success btn-block btn-lg"> LEFT SIDE <br>1</b>
</div>	
<div class="col-md-6">
<b class="btn btn-info btn-block btn-lg"> RIGHT SIDE <br>1</b>
</div>	
</div>
</div>
</div><div style="margin-top:60px;"></div>
</div>


<div class="col-md-8 col-md-offset-2 col-sm-12">
<div class="panel panel-primary">
<div class="panel-heading"> <h1 style="color:#fff;"> FREE Member On Your Tree</h1></div>
<div class="panel-body">
<div class="row">
<div class="col-md-6">
<b class="btn btn-success btn-block btn-lg"> LEFT SIDE <br>6</b>
</div>	
<div class="col-md-6">
<b class="btn btn-info btn-block btn-lg"> RIGHT SIDE <br>5</b>
</div>	
</div>
</div>
</div>
</div>









</div><!--/end row-->
</div><!--/end container-->
</div>
<!--=== End Registre ===-->
