<input type="hidden" value="<?php echo $param2 ?>" name="user_id">
<h1> Are sure you want to activate this account</h1>