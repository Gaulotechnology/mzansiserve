
<!--=== Registre ===-->

<div class="row">

<div class="col-md-12">


<!-- BEGIN EXAMPLE TABLE PORTLET-->
<div class="portlet light bordered">
<div class="portlet-title">
<div class="caption font-dark">
<span class="caption-subject bold uppercase"> Transaction History</span>
</div>
<div class="tool"> </div>
</div>
<div class="portlet-body">
<table class="table table-striped table-bordered table-hover" id="sample_1">
<thead>



<tr>
<th> SL# </th>
<th> Transaction Number </th>
<th> Transected on </th>
<th> Description </th>
<th> Amount </th>
<th> Post Balance </th>
</tr>

</thead><tbody>

                                
<tr>

<td>0001</td>
<td>161231039049</td>
<td>2016-12-31 03:24:48</td>
<td>Matching Bonus Of 1 Users</td>
<td><b class='btn btn-success btn-xs'> 1 EUR </b></td>
<td>1416 EUR</td>




</tr>                                
<tr>

<td>0002</td>
<td>161231028928</td>
<td>2016-12-31 02:39:07</td>
<td>Fund Removed By Admin</td>
<td><b class='btn btn-danger btn-xs'> -10 EUR </b></td>
<td>1415 EUR</td>




</tr>                                
<tr>

<td>0003</td>
<td>161231023044</td>
<td>2016-12-31 02:37:58</td>
<td>Fund Added By Admin</td>
<td><b class='btn btn-success btn-xs'> 10 EUR </b></td>
<td>1425 EUR</td>




</tr>                                
<tr>

<td>0004</td>
<td>161231027653</td>
<td>2016-12-31 02:14:25</td>
<td>Referral Commision From tlrtlr</td>
<td><b class='btn btn-success btn-xs'> 10 EUR </b></td>
<td>1415 EUR</td>




</tr>                                
<tr>

<td>0005</td>
<td>161231024776</td>
<td>2016-12-31 02:14:14</td>
<td>Transfer 100 USD TO tlrtlr </td>
<td><b class='btn btn-danger btn-xs'> -100 EUR </b></td>
<td>1405 EUR</td>




</tr>                                
<tr>

<td>0006</td>
<td>161231027776</td>
<td>2016-12-31 02:02:26</td>
<td>Upgrade To Premium</td>
<td><b class='btn btn-danger btn-xs'> -50 EUR </b></td>
<td>1505 EUR</td>




</tr>                                           

</tbody>
</table>
</div>
</div>
<!-- END EXAMPLE TABLE PORTLET-->

</div>



















<div style="margin-top:100px;"></div>




</div><!--/end row-->

<!--=== End Registre ===-->

