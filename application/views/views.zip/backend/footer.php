


<script src="<?php echo base_url() ?>assets/js/vendor.minf9e3.js"></script>
<script src="<?php echo base_url() ?>assets/js/elephant.minf9e3.js"></script>
<script src="<?php echo base_url() ?>assets/js/application.minf9e3.js"></script>
<script src="<?php echo base_url() ?>assets/js/demo.minf9e3.js"></script>
<script src="<?php echo base_url() ?>assets/js/demo.minf9e3.js"></script>
<script src="<?php echo base_url() ?>assets/js/profile.minf9e3.js"></script>
<script src="<?php echo base_url() ?>assets/js/compose.minf9e3.js"></script>

<!-- Footer -->
<footer class="main">
	&copy; <?php echo date("Y"); ?> gaulotechnology.co.nf <strong> Android Manager</strong>. 
    Developed by Gaudencio Solivatore </footer>
