
	<div class="banner text-center">
	  <div class="container">    
			<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with Resale</h1>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
			<a href="<?php echo base_url() ?>post_ad">Post Free Ad</a>
	  </div>
	</div>
	<!-- Categories -->
	<!--Vertical Tab-->
	<div class="categories-section main-grid-border">
		<div class="container">
			<h2 class="head">Main Categories</h2>
			<div class="category-list">
				<div id="parentVerticalTab">
					<ul class="resp-tabs-list hor_1">
						<li>Mobiles</li>
						<li>Electronics & Appliances</li>
						<li>Cars</li>
						<li>Bikes</li>
						<li>Furniture</li>
						<li>Pets</li>
						<li>Books, Sports & Hobbies</li>
						<li>Fashion</li>
						<li>Kids</li>
						<li>Services</li>
						<li>Jobs</li>
						<li>Real Estate</li>
						<a href="all-classifieds.html">All Ads</a>
					</ul>
					<div class="resp-tabs-container hor_1">
						<span class="active total" style="display:block;" data-toggle="modal" data-target="#myModal"><strong>All USA</strong> (Select your city to see local ads)</span>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat1.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Mobiles</h4>
									<span>5,12,850 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>mobiles">mobile phones</a></li>
									<li><a href="<?php echo base_url() ?>mobiles">Tablets</a></li>
									<li><a href="<?php echo base_url() ?>mobiles">Accessories</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat2.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Electronics & Appliances</h4>
									<span>2,01,850 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>electronics_appliances">Computers & accessories</a></li>
									<li><a href="<?php echo base_url() ?>electronics_appliances">Tv - video - audio</a></li>
									<li><a href="<?php echo base_url() ?>electronics_appliances">Cameras & accessories</a></li>
									<li><a href="<?php echo base_url() ?>electronics_appliances">Games & Entertainment</a></li>
									<li><a href="<?php echo base_url() ?>electronics_appliances">Fridge - AC - Washing Machine</a></li>
									<li><a href="<?php echo base_url() ?>electronics_appliances">Kitchen & Other Appliances</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat3.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Cars</h4>
									<span>1,98,080 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>cars">Commercial Vehicles</a></li>
									<li><a href="<?php echo base_url() ?>cars">Other Vehicles</a></li>
									<li><a href="<?php echo base_url() ?>cars">Spare Parts</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat4.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Bikes</h4>
									<span>6,17,568 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>bikes">Motorcycles</a></li>
									<li><a href="<?php echo base_url() ?>bikes">Scooters</a></li>
									<li><a href="<?php echo base_url() ?>bikes">Bicycles</a></li>
									<li><a href="<?php echo base_url() ?>bikes">Spare Parts</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat5.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Furniture</h4>
									<span>1,05,168 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>furnitures">Sofa & Dining</a></li>
									<li><a href="<?php echo base_url() ?>furnitures">Beds & Wardrobes</a></li>
									<li><a href="<?php echo base_url() ?>furnitures">Home Decor & Garden</a></li>
									<li><a href="<?php echo base_url() ?>furnitures">Other Household Items</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat6.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Pets</h4>
									<span>1,77,816 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>pets">Dogs</a></li>
									<li><a href="<?php echo base_url() ?>pets">Aquariums</a></li>
									<li><a href="<?php echo base_url() ?>pets">Pet Food & Accessories</a></li>
									<li><a href="<?php echo base_url() ?>pets">Other Pets</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat7.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Books, Sports & Hobbies</h4>
									<span>9,58,458 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>books_sports_hobbies">Books & Magazines</a></li>
									<li><a href="<?php echo base_url() ?>books_sports_hobbies">Musical Instruments</a></li>
									<li><a href="<?php echo base_url() ?>books_sports_hobbies">Sports Equipment</a></li>
									<li><a href="<?php echo base_url() ?>books_sports_hobbies">Gym & Fitness</a></li>
									<li><a href="<?php echo base_url() ?>books_sports_hobbies">Other Hobbies</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat8.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Fashion</h4>
									<span>3,52,345 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>fashion">Clothes</a></li>
									<li><a href="<?php echo base_url() ?>fashion">Footwear</a></li>
									<li><a href="<?php echo base_url() ?>fashion">Accessories</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat9.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Kids</h4>
									<span>8,45,298 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>kids">Furniture And Toys</a></li>
									<li><a href="<?php echo base_url() ?>kids">Prams & Walkers</a></li>
									<li><a href="<?php echo base_url() ?>kids">Accessories</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat10.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Services</h4>
									<span>7,58,867 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>services">Education & Classes</a></li>
									<li><a href="<?php echo base_url() ?>services">Web Development</a></li>
									<li><a href="<?php echo base_url() ?>services">Electronics & Computer Repair</a></li>
									<li><a href="<?php echo base_url() ?>services">Maids & Domestic Help</a></li>
									<li><a href="<?php echo base_url() ?>services">Health & Beauty</a></li>
									<li><a href="<?php echo base_url() ?>services">Movers & Packers</a></li>
									<li><a href="<?php echo base_url() ?>services">Drivers & Taxi</a></li>
									<li><a href="<?php echo base_url() ?>services">Event Services</a></li>
									<li><a href="<?php echo base_url() ?>services">Other Services</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat11.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Jobs</h4>
									<span>5,74,547 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>jobs">Customer Service</a></li>
									<li><a href="<?php echo base_url() ?>jobs">IT</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Online</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Marketing</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Advertising & PR</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Sales</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Clerical & Administration</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Human Resources</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Education</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Hotels & Tourism</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Accounting & Finance</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Manufacturing</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Part - Time</a></li>
									<li><a href="<?php echo base_url() ?>jobs">Other Jobs</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div>
							<div class="category">
								<div class="category-img">
									<img src="<?php echo base_url() ?>assets/homepage/images/cat12.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Real Estate</h4>
									<span>98,156 Ads</span>
									<a href="all-classifieds.html">View all Ads</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="sub-categories">
								<ul>
									<li><a href="<?php echo base_url() ?>real_estate">Houses</a></li>
									<li><a href="<?php echo base_url() ?>real_estate">Apartments</a></li>
									<li><a href="<?php echo base_url() ?>real_estate">PG & Roommates</a></li>
									<li><a href="<?php echo base_url() ?>real_estate">Land & Plots</a></li>
									<li><a href="<?php echo base_url() ?>real_estate">Shops - Offices - Commercial Space</a></li>
									<li><a href="<?php echo base_url() ?>real_estate">Vacation Rentals - Guest Houses</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!--Plug-in Initialisation-->
	<script type="text/javascript">
    $(document).ready(function() {

        //Vertical Tab
        $('#parentVerticalTab').easyResponsiveTabs({
            type: 'vertical', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo2');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
    });
</script>
	<!-- //Categories -->
	