

	<div class="main-banner banner text-center">
	<div class="container">    
			<h1>Easiest way to get to the next point Bringing services to you</h1>
			<p></p>
			<div class="col-md-4"></div>
			<div class="col-md-4">
			<a href="<?php echo base_url('page/login') ?>" style="width:50%;">Add Service</a>
			<a style="background:#01a115;"  data-toggle="modal" data-target="#modal-default" style="width:50%;">Request Service</a>
			</div>
			<div class="col-md-4"></div>
						</div>
	</div>
		<!-- content-starts-here -->
		<div class="content">
			<div class="categories">
				<div class="container">
					<div class="col-md-3 focus-grid">
						<a href="<?php echo base_url() ?>page/professional">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-mobile"></i></div>
									<h4 class="clrchg">Professional Services</h4>
								</div>
							</div>
						</a>
					</div>
					<div class="col-md-3 focus-grid">
						<a href="<?php echo base_url() ?>page/book_trip">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-map-marker"></i></div>
									<h4 class="clrchg">Book a Trip</h4>
								</div>
							</div>
						</a>
					</div>
					<div class="col-md-3 focus-grid">
						<a href="<?php echo base_url() ?>page/service_provider">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-gears"></i></div>
									<h4 class="clrchg">Service Providers</h4>
								</div>
							</div>
						</a>
					</div>	
					
					<div class="col-md-3 focus-grid">
						<a href="<?php echo base_url() ?>page/products">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-book"></i></div>
									<h4 class="clrchg">products</h4>
								</div>
							</div>
						</a>
					</div>	
					
				
					<div class="clearfix"></div>
				</div>
			</div>
			
			<div class="mobile-app">
				<div class="container">
					<div class="col-md-5 app-left">
						<a href="<?php echo base_url() ?>mobileapp"><img src="<?php echo base_url() ?>assets/homepage/images/app.png" alt=""></a>
					</div>
					<div class="col-md-7 app-right">
						<h3>MzansiServe App is the <span>Easiest</span> way for delivering and providing services to you</h3>
						<p>Easiest way to get to the next point Bringing services to you</p>
						<div class="app-buttons">
							<div class="app-button">
								<a href="#"><img src="<?php echo base_url() ?>assets/homepage/images/1.png" alt=""></a>
							</div>
							<div class="app-button">
								<a href="#"><img src="<?php echo base_url() ?>assets/homepage/images/2.png" alt=""></a>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		