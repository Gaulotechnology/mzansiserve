
	<div class="banner text-center">
	  <div class="container">    
			<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with Resale</h1>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
			<a href="<?php echo base_url() ?>post_ad">Post Free Ad</a>
	  </div>
	</div>
	<!-- Regions -->
		<div class="container">
			<h2 class="head">Sitemap</h2>
		</div>
		<div class="sitemap-regions">
			<div class="container">
				<div class="sitemap-region-grid">
					<div class="sitemap-region">
						<h4>Furniture</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>furnitures">Sofa & Dining</a></li>
							<li><a href="<?php echo base_url() ?>furnitures">Other Household Items</a></li>
							<li><a href="<?php echo base_url() ?>furnitures">Beds & Wardrobes</a></li>
							<li><a href="<?php echo base_url() ?>furnitures">Home Decor & Garden</a></li>
							<li><a href="<?php echo base_url() ?>furnitures">Kitchen & Other Appliances</a></li>
							<li><a href="<?php echo base_url() ?>furnitures">Fridge - AC - Washing Machine</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>furnitures">Fridges</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>furnitures">AC</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>furnitures">Washing Machine</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Services</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>services">Other Services</a></li>
							<li><a href="<?php echo base_url() ?>services">Education & Classes</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Tutoring</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Other</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Computer</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Language Classes</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Music & Dance</a></li>
							<li><a href="<?php echo base_url() ?>services">Drivers & Taxi</a></li>
							<li><a href="<?php echo base_url() ?>services">Web Development</a></li>
							<li><a href="<?php echo base_url() ?>services">Electronics & Computer Repair</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Computer</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Home Appliances</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Other Electronics</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>services">Mobile</a></li>
							<li><a href="<?php echo base_url() ?>services">Health & Beauty</a></li>
							<li><a href="<?php echo base_url() ?>services">Event Services</a></li>
							<li><a href="<?php echo base_url() ?>services">Movers & Packers</a></li>
							<li><a href="<?php echo base_url() ?>services">Maids & Domestic Help</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Real Estate</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>real_estate">Land & Plots</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Sale</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Rent</a></li>
							<li><a href="<?php echo base_url() ?>real_estate">Apartments</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Rent</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Sale</a></li>
							<li><a href="<?php echo base_url() ?>real_estate">Houses</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Rent</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Sale</a></li>
							<li><a href="<?php echo base_url() ?>real_estate">Shops - Offices - Commercial Space</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Lease</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>real_estate">Sale</a></li>
							<li><a href="<?php echo base_url() ?>real_estate">PG & Roommates</a></li>
							<li><a href="<?php echo base_url() ?>real_estate">Vacation Rentals - Guest Houses</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Bikes</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>bikes">Motorcycles</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Bajaj</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Hero Honda</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Yamaha</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Royal Enfield</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Honda</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Hero</a></li>
							<li><a href="<?php echo base_url() ?>bikes">TVS</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Suzuki</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Other Brands</a></li>
							<li><a href="<?php echo base_url() ?>bikes">KTM</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Mahindra</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Kawasaki</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Harley Davidson</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Spare Parts</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Scooters</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Honda</a></li>
							<li><a href="<?php echo base_url() ?>bikes">TVS </a></li>
							<li><a href="<?php echo base_url() ?>bikes">Bajaj</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Hero</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Suzuki</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Mahindra</a></li>
							<li><a href="<?php echo base_url() ?>bikes">LML</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Kinetic</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Other Brands</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Yamaha</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Vespa</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Lambretta</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Bicycles</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Hero</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Other Brands</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Hercules</a></li>
							<li><a href="<?php echo base_url() ?>bikes">BSA</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Atlas</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Avon</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Firefox</a></li>
							<li><a href="<?php echo base_url() ?>bikes">Trek</a></li>
						</ul>
					</div>
				</div>
				<div class="sitemap-region-grid">
					<div class="sitemap-region">
						<h4>Jobs</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>jobs">Online</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Other Jobs</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Customer Service</a></li>
							<li><a href="<?php echo base_url() ?>jobs">IT</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Marketing</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Sales</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Manufacturing</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Clerical & Administration</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Hotels & Tourism</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Accounting & Finance</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Advertising & PR</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Human Resources</a></li>
							<li><a href="<?php echo base_url() ?>jobs">Education</a></li>
						</ul>
					</div>				
					<div class="sitemap-region">
						<h4>Cars</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>cars">Cars</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Maruti Suzuki</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Hyundai</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Tata</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mahindra</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Honda</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Ford</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Toyota</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Chevrolet</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Skoda</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Volkswagen</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Fiat</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mitsubishi</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Other Brands</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mercedes-Benz</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Nissan</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">BMW</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Renault</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Hindustan Motors</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Audi</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mahindra Renault</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Opel</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Daewoo</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Force Motors</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Landrover</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Premier</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Jaguar</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Volvo</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Isuzu</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mini</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Porsche</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Ssangyong</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mahindra Reva</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Rolls Royce</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Bentley</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Ferrari</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Lamborghini </a></li>
							<li><a href="<?php echo base_url() ?>cars">Spare Parts</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Car Parts</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Other Parts</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Spare Parts</a></li>
							<li><a href="<?php echo base_url() ?>cars">Commercial Vehicles</a></li>
							<li><a href="<?php echo base_url() ?>cars">Other Vehicles</a></li>
							<li><a href="<?php echo base_url() ?>cars">Motorcycles</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Hero Honda</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Honda</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Bajaj</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">TVS</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Royal Enfield</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Suzuki</a></li>
							<li><a href="<?php echo base_url() ?>cars">Scooters</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Honda</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Bajaj</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">TVS</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Suzuki</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Kinetic</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Mahindra</a></li>
							<li><a href="<?php echo base_url() ?>cars">Bicycles</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Other Brands</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>cars">Hero</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Pets</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>pets">Dogs</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Other Breeds</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Labrador</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">German Shepherd</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Rottweiler</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Pug</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Mastiff</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Saint Bernard</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Golden Retriever</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Beagle</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Pomeranian</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Doberman</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Husky</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Cocker Spaniel</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Boxer</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>pets">Bulldog</a></li>
							<li class="left-gap"a href="<?php echo base_url() ?>pets">Dalmatian</a></li>
							<li><a href="<?php echo base_url() ?>pets">Other Pets</a></li>
							<li><a href="<?php echo base_url() ?>pets">Aquariums</a></li>
							<li><a href="<?php echo base_url() ?>pets">Pet Food & Accessories</a></li>
						</ul>
					</div>
				</div>
				<div class="sitemap-region-grid">
					<div class="sitemap-region">					
						<h4>Mobiles</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>mobiles">Mobile Phones</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Samsung</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Nokia</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Other Mobiles</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Micromax</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">iPhone</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Sony</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">HTC</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Lenovo</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Intex</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Motorola</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Lava</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">LG</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Mi</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">BlackBerry</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Karbonn</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Asus</a></li>
							<li><a href="<?php echo base_url() ?>mobiles">Accessories</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Mobile</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Tablets</a></li>
							<li><a href="<?php echo base_url() ?>mobiles">Tablets</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Samsung</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Other Tablets</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">iPads</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">iBall</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Micromax</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Lenovo</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Asus</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">HP</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Dell</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">HCL</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Acer</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Blackberry</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>mobiles">Sony</a></li>
						</ul>
					</div>
					<div class="sitemap-region">					
						<h4>Kids</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>kids">Furniture And Toys</a></li>
							<li><a href="<?php echo base_url() ?>kids">Accessories</a></li>
							<li><a href="<?php echo base_url() ?>kids">Prams & Walkers</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Fashion</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>fashion">Accessories</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>fashion">Women</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>fashion">Men</a></li>
							<li><a href="<?php echo base_url() ?>fashion">Clothes</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>fashion">Women</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>fashion">Men</a></li>
							<li><a href="<?php echo base_url() ?>fashion">Footwear</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>fashion">Men</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>fashion">Women</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Electronics & Appliances</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>electronics_appliances">Computers & Accessories</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Laptops</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Computers</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Other Accessories</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Internet</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Printers</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Monitors</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Hard Disk</a></li>
							<li><a href="<?php echo base_url() ?>electronics_appliances">Kitchen & Other Appliances</a></li>
							<li><a href="<?php echo base_url() ?>electronics_appliances">TV - Video - Audio</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Video - Audio</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">TV</a></li>
							<li><a href="<?php echo base_url() ?>electronics_appliances">Cameras & Accessories</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Cameras</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Other Accessories</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Lenses</a></li>
							<li><a href="<?php echo base_url() ?>electronics_appliances">Games & Entertainment</a></li>
							<li><a href="<?php echo base_url() ?>electronics_appliances">Fridge - AC - Washing Machine</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Fridges</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">Washing Machine</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>electronics_appliances">AC</a></li>
						</ul>
					</div>
					<div class="sitemap-region">
						<h4>Books, Sports & Hobbies</h4>
						<ul>
							<li><a href="<?php echo base_url() ?>books_sports_hobbies">Gym & Fitness</a></li>
							<li><a href="<?php echo base_url() ?>books_sports_hobbies">Other Hobbies</a></li>
							<li><a href="<?php echo base_url() ?>books_sports_hobbies">Musical Instruments</a></li>
							<li><a href="<?php echo base_url() ?>books_sports_hobbies">Books & Magazines</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">Education & Training</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">Competitive Exam</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">Literature & Fiction</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">Professional & Technical</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">Other Books</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">School Books</a></li>
							<li class="left-gap"><a href="<?php echo base_url() ?>books_sports_hobbies">Children</a></li>
							<li><a href="<?php echo base_url() ?>books_sports_hobbies">Sports Equipment</a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	<!-- //Regions -->
	