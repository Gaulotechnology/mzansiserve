
	<div class="banner text-center">
	  <div class="container">    
			<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with Resale</h1>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
			<a href="<?php echo base_url() ?>post_ad">Post Free Ad</a>
	  </div>
	</div>
	<!-- Popular-search -->
	<div class="popular-search main-grid-border">
		<div class="container">
			<h2 class="head">Most popular search phrases</h2>
				<div class="tags">
					<p>
					<a class="tag1" href="<?php echo base_url() ?>single">At vero eos</a>
					<a class="tag2" href="<?php echo base_url() ?>single">doloremque</a>
					<a class="tag3" href="<?php echo base_url() ?>single">On the other</a>
					<a class="tag4" href="<?php echo base_url() ?>single">pain was</a>
					<a class="tag5" href="<?php echo base_url() ?>single">rationally encounter</a>
					<a class="tag6" href="<?php echo base_url() ?>single">praesentium voluptatum</a>
					<a class="tag7" href="<?php echo base_url() ?>single">est, omnis</a>
					<a class="tag8" href="<?php echo base_url() ?>single">who are so beguiled</a>
					<a class="tag9" href="<?php echo base_url() ?>single">when nothing</a>
					<a class="tag10" href="<?php echo base_url() ?>single">owing to the</a>
					<a class="tag11" href="<?php echo base_url() ?>single">pains to avoid</a>
					<a class="tag12" href="<?php echo base_url() ?>single">tempora incidunt</a>
					<a class="tag13" href="<?php echo base_url() ?>single">pursues or desires</a>
					<a class="tag14" href="<?php echo base_url() ?>single">Bonorum et</a>
					<a class="tag15" href="<?php echo base_url() ?>single">written by Cicero</a>
					<a class="tag16" href="<?php echo base_url() ?>single">Ipsum passage</a>
					<a class="tag17" href="<?php echo base_url() ?>single">exercitationem ullam</a>
					<a class="tag18" href="<?php echo base_url() ?>single">mistaken idea</a>
					<a class="tag19" href="<?php echo base_url() ?>single">ducimus qui</a>
					<a class="tag20" href="<?php echo base_url() ?>single">holds in these</a>
					</p>
				</div>
		</div>
		<div class="popular-regions">
			<div class="container">
				<h4>Regions</h4>
				<ul>
					<li><a href="<?php echo base_url() ?>regions">Alabama</a></li>
					<li><a href="<?php echo base_url() ?>regions">Alaska</a></li>
					<li><a href="<?php echo base_url() ?>regions">Arizona</a></li>
					<li><a href="<?php echo base_url() ?>regions">Arkansas</a></li>
					<li><a href="<?php echo base_url() ?>regions">California</a></li>
					<li><a href="<?php echo base_url() ?>regions">Colorado</a></li>
					<li><a href="<?php echo base_url() ?>regions">Connecticut</a></li>
					<li><a href="<?php echo base_url() ?>regions">Delaware</a></li>
					<li><a href="<?php echo base_url() ?>regions">Florida</a></li>
					<li><a href="<?php echo base_url() ?>regions">Georgia</a></li>
					<li><a href="<?php echo base_url() ?>regions">Hawaii</a></li>
					<li><a href="<?php echo base_url() ?>regions">Idaho</a></li>
					<li><a href="<?php echo base_url() ?>regions">Illinois</a></li>
					<li><a href="<?php echo base_url() ?>regions">Indiana</a></li>
					<li><a href="<?php echo base_url() ?>regions">Iowa</a></li>
					<li><a href="<?php echo base_url() ?>regions">Kansas</a></li>
					<li><a href="<?php echo base_url() ?>regions">Kentucky</a></li>
					<li><a href="<?php echo base_url() ?>regions">Louisiana</a></li>
					<li><a href="<?php echo base_url() ?>regions">Maine</a></li>
					<li><a href="<?php echo base_url() ?>regions">Maryland</a></li>
					<li><a href="<?php echo base_url() ?>regions">Massachusetts</a></li>
					<li><a href="<?php echo base_url() ?>regions">Michigan</a></li>
					<li><a href="<?php echo base_url() ?>regions">Minnesota</a></li>
					<li><a href="<?php echo base_url() ?>regions">Mississippi</a></li>
					<li><a href="<?php echo base_url() ?>regions">Missouri</a></li>
					<li><a href="<?php echo base_url() ?>regions">Montana</a></li>
					<li><a href="<?php echo base_url() ?>regions">Nebraska</a></li>
					<li><a href="<?php echo base_url() ?>regions">Nevada</a></li>
					<li><a href="<?php echo base_url() ?>regions">New Hampshire</a></li>
					<li><a href="<?php echo base_url() ?>regions">New Jersey</a></li>
					<li><a href="<?php echo base_url() ?>regions#">New Mexico</a></li>
					<li><a href="<?php echo base_url() ?>regions">New York</a></li>
					<li><a href="<?php echo base_url() ?>regions">North Carolina</a></li>
					<li><a href="<?php echo base_url() ?>regions">North Dakota</a></li>
					<li><a href="<?php echo base_url() ?>regions">Ohio</a></li>
					<li><a href="<?php echo base_url() ?>regions">Oklahoma</a></li>
					<li><a href="<?php echo base_url() ?>regions">Oregon</a></li>
					<li><a href="<?php echo base_url() ?>regions">Pennsylvania</a></li>
					<li><a href="<?php echo base_url() ?>regions">Rhode Island</a></li>
					<li><a href="<?php echo base_url() ?>regions">South Carolina</a></li>
					<li><a href="<?php echo base_url() ?>regions">South Dakota</a></li>
					<li><a href="<?php echo base_url() ?>regions">Tennessee</a></li>
					<li><a href="<?php echo base_url() ?>regions">Texas</a></li>
					<li><a href="<?php echo base_url() ?>regions">Utah</a></li>
					<li><a href="<?php echo base_url() ?>regions">Vermont</a></li>
					<li><a href="<?php echo base_url() ?>regions">Virginia</a></li>
					<li><a href="<?php echo base_url() ?>regions">Washington</a></li>
					<li><a href="<?php echo base_url() ?>regions">West Virginia</a></li>
					<li><a href="<?php echo base_url() ?>regions">Wisconsin</a></li>
					<li><a href="<?php echo base_url() ?>regions">Wyoming</a></li>
					<div class="clearfix"></div>
				</ul>
				<h4 class="mpcwc">Most popular cities in whole country</h4>
				<ul>
					<li><a href="all-classifieds.html">Birmingham</a></li>
					<li><a href="all-classifieds.html">Anchorage</a></li>
					<li><a href="all-classifieds.html">Phoenix</a></li>
					<li><a href="all-classifieds.html">Little Rock</a></li>
					<li><a href="all-classifieds.html">Los Angeles</a></li>
					<li><a href="all-classifieds.html">Denver</a></li>
					<li><a href="all-classifieds.html">Bridgeport</a></li>
					<li><a href="all-classifieds.html">Wilmington</a></li>
					<li><a href="all-classifieds.html">Jacksonville</a></li>
					<li><a href="all-classifieds.html">Atlanta</a></li>
					<li><a href="all-classifieds.html">Honolulu</a></li>
					<li><a href="all-classifieds.html">Boise</a></li>
					<li><a href="all-classifieds.html">Chicago</a></li>
					<li><a href="all-classifieds.html">Indianapolis</a></li>
					<div class="clearfix"></div>
				</ul>
			</div>
		</div>
		<div class="popular-categories">
			<div class="container">
				<div class="popular-category">
					<h4>Mobiles</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>mobiles">Iphone</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Samsung</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Iphone 6</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Iphone 5s</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Exchange</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Nokia</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Sony</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Htc</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">I phone</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Iphone 5</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Blackberry</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Cdma</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Micromax</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Iphone 4s</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Lenovo</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Apple</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Mi</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">I phone 6</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">I phone 5s</a></li>
						<li><a href="<?php echo base_url() ?>mobiles">Moto</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Electronics & Appliances</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Laptop</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Dj</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Tv</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Projector</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Led tv</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Speakers</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Home theater</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Laptops</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Printer</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Speaker</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Led</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Amplifier</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Generator</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Music system</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Washing machine</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Camera</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Sony</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Fridge</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Cpu</a></li>
						<li><a href="<?php echo base_url() ?>electronics_appliances">Ac</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Cars</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>cars">Innova</a></li>
						<li><a href="<?php echo base_url() ?>cars">Scorpio</a></li>
						<li><a href="<?php echo base_url() ?>cars">Jeep</a></li>
						<li><a href="<?php echo base_url() ?>cars">Alto</a></li>
						<li><a href="<?php echo base_url() ?>cars">Maruti 800</a></li>
						<li><a href="<?php echo base_url() ?>cars">Bolero</a></li>
						<li><a href="<?php echo base_url() ?>cars">Zen</a></li>
						<li><a href="<?php echo base_url() ?>cars">Honda city</a></li>
						<li><a href="<?php echo base_url() ?>cars">Delhi</a></li>
						<li><a href="<?php echo base_url() ?>cars">Omni</a></li>
						<li><a href="<?php echo base_url() ?>cars">Tavera</a></li>
						<li><a href="<?php echo base_url() ?>cars">Indica</a></li>
						<li><a href="<?php echo base_url() ?>cars">Santro</a></li>
						<li><a href="<?php echo base_url() ?>cars">Bmw</a></li>
						<li><a href="<?php echo base_url() ?>cars">Mumbai</a></li>
						<li><a href="<?php echo base_url() ?>cars">Tata sumo</a></li>
						<li><a href="<?php echo base_url() ?>cars">Kerala</a></li>
						<li><a href="<?php echo base_url() ?>cars">Swift vdi</a></li>
						<li><a href="<?php echo base_url() ?>cars">Fortuner</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Bikes</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>bikes">Bullet</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Royal enfield</a></li>
						<li><a href="<?php echo base_url() ?>bikes">R15</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Fz</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Activa</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Pulsar</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Yamaha</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Mumbai</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Ktm</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Pulsar 220</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Bangalore</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Rx</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Pune</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Apache</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Harley davidson</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Delhi</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Kolkata</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Hyderabad</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Karizma</a></li>
						<li><a href="<?php echo base_url() ?>bikes">Unicorn</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Furniture</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>furnitures">Sofa</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Bed</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Dining table</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Sofa set</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Almirah</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Table</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Sofa cum bed</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Chair</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Double bed</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Computer table</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Antique</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Chairs</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Study table</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Office table</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Dressing table</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Tv stand</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Mumbai</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Wardrobe</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Cupboard</a></li>
						<li><a href="<?php echo base_url() ?>furnitures">Pune</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Pets</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>pets">Cow</a></li>
						<li><a href="<?php echo base_url() ?>pets">Cows</a></li>
						<li><a href="<?php echo base_url() ?>pets">Goat</a></li>
						<li><a href="<?php echo base_url() ?>pets">Cat</a></li>
						<li><a href="<?php echo base_url() ?>pets">Aseel</a></li>
						<li><a href="<?php echo base_url() ?>pets">Horse</a></li>
						<li><a href="<?php echo base_url() ?>pets">Pigeons</a></li>
						<li><a href="<?php echo base_url() ?>pets">Pigeon</a></li>
						<li><a href="<?php echo base_url() ?>pets">Goats</a></li>
						<li><a href="<?php echo base_url() ?>pets">Cats</a></li>
						<li><a href="<?php echo base_url() ?>pets">Birds</a></li>
						<li><a href="<?php echo base_url() ?>pets">Rottweiler</a></li>
						<li><a href="<?php echo base_url() ?>pets">Rabbit</a></li>
						<li><a href="<?php echo base_url() ?>pets">Pug</a></li>
						<li><a href="<?php echo base_url() ?>pets">Pitbull</a></li>
						<li><a href="<?php echo base_url() ?>pets">German shepherd</a></li>
						<li><a href="<?php echo base_url() ?>pets">Buffalo</a></li>
						<li><a href="<?php echo base_url() ?>pets">Labrador</a></li>
						<li><a href="<?php echo base_url() ?>pets">Dog</a></li>
						<li><a href="<?php echo base_url() ?>pets">Hens</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Books, Sports & Hobbies</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Coin</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Books</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Bat</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Football</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Treadmill</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Guitar</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Coins</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Moradabad</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Cycle</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Antique</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Gym</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Carrom board</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Book</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Shoes</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Cricket bat</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Sport</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">East india</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Skates</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Cricket bats</a></li>
						<li><a href="<?php echo base_url() ?>books_sports_hobbies">Sports</a></li>
					</ul>
				</div>	
				<div class="popular-category">
					<h4>Fashion</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>fashion">Watch</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Watches</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Mumbai</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Shoes</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Jewellery</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Bag</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Saree</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Jacket</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Hyderabad</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Kolkata</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Kerala</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Delhi</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Bra</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Bags</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Ahmedabad</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Bangalore</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Sarees</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Sunglasses</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Gold</a></li>
						<li><a href="<?php echo base_url() ?>fashion">Nike</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Kids</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>kids">Car</a></li>
						<li><a href="<?php echo base_url() ?>kids">Cycle</a></li>
						<li><a href="<?php echo base_url() ?>kids">Mumbai</a></li>
						<li><a href="<?php echo base_url() ?>kids">Toys</a></li>
						<li><a href="<?php echo base_url() ?>kids">Bike</a></li>
						<li><a href="<?php echo base_url() ?>kids">High chair</a></li>
						<li><a href="<?php echo base_url() ?>kids">Delhi</a></li>
						<li><a href="<?php echo base_url() ?>kids">Cycles</a></li>
						<li><a href="<?php echo base_url() ?>kids">Pune</a></li>
						<li><a href="<?php echo base_url() ?>kids">Stroller</a></li>
						<li><a href="<?php echo base_url() ?>kids">Hyderabad</a></li>
						<li><a href="<?php echo base_url() ?>kids">Cars</a></li>
						<li><a href="<?php echo base_url() ?>kids">Walker</a></li>
						<li><a href="<?php echo base_url() ?>kids">Tricycle</a></li>
						<li><a href="<?php echo base_url() ?>kids">Baby walker</a></li>
						<li><a href="<?php echo base_url() ?>kids">Car seat</a></li>
						<li><a href="<?php echo base_url() ?>kids">Cradle</a></li>
						<li><a href="<?php echo base_url() ?>kids">Kids cycle</a></li>
						<li><a href="<?php echo base_url() ?>kids">Kolkata baby</a></li>
						<li><a href="<?php echo base_url() ?>kids">Battery car</a></li>
					</ul>
				</div>
				<div class="popular-category">
					<h4>Services</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>services">Vip numbers</a></li>
						<li><a href="<?php echo base_url() ?>services">Fancy number</a></li>
						<li><a href="<?php echo base_url() ?>services">Insurance</a></li>
						<li><a href="<?php echo base_url() ?>services">Rent a car</a></li>
						<li><a href="<?php echo base_url() ?>services">Massage</a></li>
						<li><a href="<?php echo base_url() ?>services">Driver</a></li>
						<li><a href="<?php echo base_url() ?>services">Fancy numbers</a></li>
						<li><a href="<?php echo base_url() ?>services">Service</a></li>
						<li><a href="<?php echo base_url() ?>services">Vip number</a></li>
						<li><a href="<?php echo base_url() ?>services">Business</a></li>
						<li><a href="<?php echo base_url() ?>services">Loans</a></li>
						<li><a href="<?php echo base_url() ?>services">Cook</a></li>
						<li><a href="<?php echo base_url() ?>services">Distributors</a></li>
						<li><a href="<?php echo base_url() ?>services">Travel</a></li>
						<li><a href="<?php echo base_url() ?>services">Services</a></li>
						<li><a href="<?php echo base_url() ?>services">Pop up calls</a></li>
						<li><a href="<?php echo base_url() ?>services">Icloud</a></li>
						<li><a href="<?php echo base_url() ?>services">Visa</a></li>
						<li><a href="<?php echo base_url() ?>services">Kerala rent car</a></li>
						<li><a href="<?php echo base_url() ?>services">Partners</a></li>
					</ul>
				</div>	
				<div class="popular-category">
					<h4>Jobs</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>jobs">Driver</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Fresher</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Driver job</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Delivery boy</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Kolkata</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Part time</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Teacher</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Driver jobs</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Office boy</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Data entry</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Delhi</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Computer operator</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Data entry</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Graphic designer</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Receptionist</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Mumbai</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Part time job</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Work from home</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Accounting finance</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Cook</a></li>
						<li><a href="<?php echo base_url() ?>jobs">Airport	</a></li>
					</ul>
				</div>	
				<div class="popular-category">
					<h4>Real Estate</h4>
					<ul>
						<li><a href="<?php echo base_url() ?>real_estate">House for sale</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Rent</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Wayanad</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Thodupuzha</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Kothamangalam</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Muvattupuzha</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Pala</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Sale</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Agriculture land</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">House for rent</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Irinjalakuda</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Kottayam</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Powai</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Changanacherry</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Aluva</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Shop</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Land</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">House</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Hyderabad</a></li>
						<li><a href="<?php echo base_url() ?>real_estate">Pathanamthitta</a></li>
					</ul>
				</div>					
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //Popular-search -->
	