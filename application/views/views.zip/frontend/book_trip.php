
	<div class="banner text-center">
    <div class="container">    
			<h1>Easiest way to get to the next point Bringing services to you</h1>
			<p></p>
			<div class="col-md-4"></div>
			<div class="col-md-4">
			<a href="<?php echo base_url('page/login') ?>" style="width:50%;">Add Service</a>
			<a style="background:#01a115;"  data-toggle="modal" data-target="#modal-default" style="width:50%;">Request Service</a>
			</div>
			<div class="col-md-4"></div>
						</div>
	</div>
	<!-- Services -->
	<div class="total-ads main-grid-border">
		<div class="container">
			<div class="select-box">
				<div class="select-city-for-local-ads ads-list">
					<label>Select your pick up Loction</label>
						<select>
						<optgroup label="Popular Cities">
						<option selected style="display:none;color:#eee;">Current Location</option>
													
						</optgroup>
																								
													
                        </select>
                        
				</div>
				<div class="browse-category ads-list">
					<label>Select your Destination</label>
					<select class="selectpicker show-tick" data-live-search="true">
					  <option data-tokens="Services">Destination Location</option>
					  
					</select>
				</div>
				
				<div class="clearfix"></div>
			</div>
			<ol class="breadcrumb" style="margin-bottom: 5px;">
			  <li><a href="index.html">Home</a></li>
			  <li><a href="categories.html">Categories</a></li>
			  <li class="active">Services</li>
			</ol>
			<div class="ads-grid">
			
				<div class="ads-display col-md-12">
					<div class="wrapper">					
					<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					  <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
					  </ul>
					  <div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
						   <div>
												<div id="container">
								<div class="view-controls-list" id="viewcontrols">
									<label>Google Maps View :</label>
					
										<!-- MAPS -->

										<!-- MAPS -->

										</div>
								<div class="clearfix"></div>
							
						</div>
							</div>
						</div>
						
					  </div>
					</div>
				</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>	
	</div>
	