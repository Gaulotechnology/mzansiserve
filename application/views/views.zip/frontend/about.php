
	<div class="banner text-center">
	<div class="container">    
			<h1>Easiest way to get to the next point Bringing services to you</h1>
			<p></p>
			<div class="col-md-4"></div>
			<div class="col-md-4">
			<a href="<?php echo base_url('page/login') ?>" style="width:50%;">Add Service</a>
			<a style="background:#01a115;"  data-toggle="modal" data-target="#modal-default" style="width:50%;">Request Service</a>
			</div>
			<div class="col-md-4"></div>
						</div>
	</div>
	<!-- How it works -->
		<div class="work-section">
			<div class="container">
				<h2 class="head">About</h2>
					<div class="work-section-head text-center">
						<p>Fast, easy and free to add a service and you will find, what you are looking for.</p>
					</div>
					<div class="work-section-grids text-center">
						<div class="col-md-3 work-section-grid">
							<i class="fa fa-pencil-square-o"></i>
							<h4>Post a service</h4>
							<p>The Service provider registers, his gps location, gets picked and other details are captured</p>
							<span class="arrow1"><img src="<?php echo base_url() ?>assets/homepage/images/arrow1.png" alt="" /></span>
						</div>
						<div class="col-md-3 work-section-grid">
							<i class="fa fa-eye"></i>
							<h4>Find a Service</h4>
							<p>A Random user can search for a service but login will required in order to transact</p>
							<span class="arrow2"><img src="<?php echo base_url() ?>assets/homepage/images/arrow2.png" alt="" /></span>
						</div>
						<div class="col-md-3 work-section-grid">
							<i class="fa fa-phone"></i>
							<h4>Request the  service</h4>
							<p>The service provider accepts the request, then you can transact</p>
							<span class="arrow1"><img src="<?php echo base_url() ?>assets/homepage/images/arrow1.png" alt="" /></span>
						</div>
						<div class="col-md-3 work-section-grid">
							<i class="fa fa-money"></i>
							<h4>make transactions</h4>
							<p>If your payment card is linked you can perfom the transaction straight away</p>
						</div>
						<div class="clearfix"></div>
						<a class="work" href="#">Get start Now</a>
					</div>
				</div>
		</div>	
		<div class="mobile-app">
				<div class="container">
					<div class="col-md-5 app-left">
						<a href="<?php echo base_url() ?>mobileapp"><img src="<?php echo base_url() ?>assets/homepage/images/app.png" alt=""></a>
					</div>
					<div class="col-md-7 app-right">
						<h3>MzansiServe App is the <span>Easiest</span> way for delivering and providing services to you</h3>
						<p>Easiest way to get to the next point Bringing services to you</p>
						<div class="app-buttons">
							<div class="app-button">
								<a href="#"><img src="<?php echo base_url() ?>assets/homepage/images/1.png" alt=""></a>
							</div>
							<div class="app-button">
								<a href="#"><img src="<?php echo base_url() ?>assets/homepage/images/2.png" alt=""></a>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		