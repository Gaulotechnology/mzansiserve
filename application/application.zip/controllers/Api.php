<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*	
 *	@author 	: Gaudencio Solivatore
 *	date		: 27 september, 2014
 *	Android Device Management Prp
 *	
 *	gaulomail@gmail.com
 */

class Api extends CI_Controller
{
     
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    
    /***default functin, redirects to login page if no admin logged in yet***/
    public function index()
    {
        $this->load->view('backend/install');
    }
    
    function login(){
        {
            $email=$this->input->post('email');
            $password=$this->input->post('password');
            $this->db->where('email',urldecode($email));
            $query=$this->db->get('users');
            
            if ($query->num_rows()>0) {
                $r=$query->row_array();
    
                if (verifyHashedPassword(urldecode($password), $r['password'])) {
                    $response=array(
                    "status"=>"1",
                    "data"=>array(
                        "id"=>$r['user_id'],
                        "fullname"=>$r['fullname'],
                        "surname"=>$r['surname'],
                        "email"=>$r['email'],
                        "country"=>$r['country'],
                        "province"=>$r['province'],
                        "level"=>$r['level'],
                        "cellphone"=>$r['cellphone']
                        )
                    );
                    echo(json_encode($response));
                }
            }
            else{
                $response=array(
                    "status"=>"0",
                    "data"=>"Wrong Email/Password"
                    );
                echo(json_encode($response));
            }
        }
    }
    
}
