<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
* m_data_captured
*
*
* @uses     CI_Model
*
* @category Site
* @package  OnlineGuarding
* @author    Elsabe Lessing (http://www.lessink.co.za)
*/
class m_car_type extends CI_Model {
    private $table_name = 'vehicles';
   

   

    function __construct() {
        parent::__construct();
        $this->load->library('email');
        $this->load->database('default');
    }


    public function addNew($data=null){
       
        $addNew['name']= $data['name'];
          
        $this->db->insert($this->table_name, $addNew);
        return $this->db->insert_id();
       
    }
    function count_all(){
        $this->db->from($this->table_name);
        return $this->db->count_all_results();
      }
    function get_name_by_id($id=null){
       $this->db->where('id', $id);

        $query=$this->db->get($this->table_name);
        if($query->num_rows()>0){
            return $query->row();
        }
    }
     /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function carsListing($page=null, $segment=null, $user_id=null)
    {
            $this->db->select('A.*, B.*');
            $this->db->join('users B','B.user_id=A.user_id');
            if(isset($user_id)){
                $this->db->where('B.user_id',  $user_id);
            }
            $this->db->limit($page, $segment);
            $query=$this->db->get($this->table_name." A");
            if($query && $query->num_rows()>0){
                return $query->result();
            }
    }
    

    /**
     * @method get_all
     */
    function get_all(){
        $cars[]="MAZDA";
        $cars[]="NISSAN";
        $cars[]="BMW";
        $cars[]="MERCEDES";
        $cars[]="VW";
        $cars[]="OPEL";
        $cars[]="JEEP";
        $cars[]="MAHiNDRA";
        $cars[]="TOYOTA";
        $cars[]="FORD";
        $cars[]="CHRYSTLER";
        $cars[]="FERRARI";
        $cars[]="AUDI";
        $cars[]="BENTELY";
return $cars;
     }
     /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function delete_cars($data){
        foreach ($data as $deb) {
            $this->db->where('id', $deb);
            $this->db->delete($this->table_name);
            return $this->db->affected_rows();
        }
    }
    
}
