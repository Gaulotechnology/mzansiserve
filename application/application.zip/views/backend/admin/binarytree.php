<link rel="shortcut icon" href="http://localhost/mlm2/member/favicon.ico">

	<!-- Web Fonts -->
	<link rel='stylesheet' type='text/css' href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

	<!-- CSS Global Compulsory -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/plugins/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/shop.style.css">

	<!-- CSS Header and Footer -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/headers/header-v5.css">
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/footers/footer-v4.css">

	<!-- CSS Implementing Plugins -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/plugins/animate.css">
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/plugins/line-icons/line-icons.css">
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/plugins/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/plugins/scrollbar/css/jquery.mCustomScrollbar.css">

	<!-- CSS Page Styles -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/pages/log-reg-v3.css">

	<!-- Style Switcher -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/plugins/style-switcher.css">

	<!-- CSS Theme -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/theme-colors/default.css" id="style_color">

	<!-- CSS Customization -->
	<link rel="stylesheet" href="http://localhost/mlm2/member/assets/css/custom.css"><style>
	
.userInfo {
 display: none;
}
.user {
  width: 70px;
  text-align: center;
}

</style>
<!--=== Registre ===-->

<div class="row">





<form action="http://localhost/mlm2/member/Tree/" method="get">


<div class="col-md-12">
<div class="row">


<div class="col-md-3 col-md-offset-3">
<div class="form-group">
<input class="form-control input-lg" placeholder="USERNAME" name="name" type="text" required="">
</div>
</div>


<div class="col-md-3">

<button type="submit" class="btn btn-success btn-lg btn-block"> SEARCH </button>
</div>


</div>
</div>


</form>


<div style="margin-top:100px;"></div>








<div class="col-xs-12">







<!--==================ROOT==================-->

<div class="row">


<div class="col-xs-6 col-xs-offset-3" >

<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/1.png" width="30px" alt="**" style="width:100%;">
admin<div class="userInfo">



<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/admin'><h1>admin</h1></a></div>
<div class="panel-body">
<h1>  </h1> <b class="btn btn-primary btn-block">PAID</b><b>Referred By:</b>  <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-1 | R-1 <br><b>Free Member Below:</b> L-6 | R-5 <br></div></div>

</div>	
</div>
</div>
</div>
<!--==================ROOT==================-->









<div style="margin-top:100px;"></div>





















<!--================================================LEFT================================================-->

<div class="row">
<div class="col-xs-5">




<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/1.png" alt="**" style="width:100%;">
abirkhan75<div class="userInfo">



<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/abirkhan75'><h2>abirkhan75</h2></a></div>
<div class="panel-body">
<h2>ABIR KHAN </h2> <b class="btn btn-primary btn-block">PAID</b><b>Referred By:</b> admin <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-0 | R-0 <br><b>Free Member Below:</b> L-5 | R-1 <br></div></div>
</div></div>


<div style="margin-top:100px;"></div>
<!--==================3 L==================-->
<div class="row">




<div class="col-xs-5">

<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/1.png" alt="**" style="width:100%;">
abirkhan750<div class="userInfo">



<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/abirkhan750'><h3>abirkhan750</h3></a></div>
<div class="panel-body">
<h3>AA AA </h3> <b class="btn btn-primary btn-block">PAID</b><b>Referred By:</b> abirkhan75 <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-0 | R-0 <br><b>Free Member Below:</b> L-3 | R-1 <br></div></div>
</div></div>

</div>	






<div class="col-xs-5 col-xs-offset-2">

<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/1.png" alt="**" style="width:100%;">
abirkhan75r<div class="userInfo">



<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/abirkhan75r'><h3>abirkhan75r</h3></a></div>
<div class="panel-body">
<h3>ABIRKHAN75R ABIRKHAN75R </h3> <b class="btn btn-primary btn-block">PAID</b><b>Referred By:</b> abirkhan75 <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-0 | R-0 <br><b>Free Member Below:</b> L-0 | R-0 <br></div></div>
</div></div>

</div>	


	
</div>

<!--==================3 L==================-->



</div>	





<!--================================================LEFT================================================-->

















<!--================================================RIGHT================================================-->


<div class="col-xs-5 col-xs-offset-2">



<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/1.png" alt="**" style="width:100%;">
tlrtlr<div class="userInfo">

<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/tlrtlr'><h2>tlrtlr</h2></a></div>
<div class="panel-body">
<h2>TLR TLR </h2> <b class="btn btn-primary btn-block">PAID</b><b>Referred By:</b> admin <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-0 | R-0 <br><b>Free Member Below:</b> L-1 | R-4 <br></div></div>
</div></div>


<div style="margin-top:100px;"></div>
<!--==================3 L==================-->
<div class="row">




<div class="col-xs-5">

<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/0.png" alt="**" style="width:100%;">
tlrtlrtlrtlrtlrtlr<div class="userInfo">


<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/tlrtlrtlrtlrtlrtlr'><h3>tlrtlrtlrtlrtlrtlr</h3></a></div>
<div class="panel-body">
<h3>TLRTLR TLRTLR </h3> <b class="btn btn-warning btn-block">FREE</b><b>Referred By:</b> tlrtlr <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-0 | R-0 <br><b>Free Member Below:</b> L-0 | R-0 <br></div></div>
</div></div>

</div>	






<div class="col-xs-5 col-xs-offset-2">

<div class="user" style="text-align: center; margin: auto;">
<img src="http://localhost/mlm2/member/assets/img/0.png" alt="**" style="width:100%;">
tlrtlrtlrtlr<div class="userInfo">


<div class="panel panel-success" style="text-align: center;">
<div class="panel-heading"><a href='http://localhost/mlm2/member/Tree/tlrtlrtlrtlr'><h3> tlrtlrtlrtlr</h3></a></div>
<div class="panel-body">
<h3>TLRTLR TLRTLR </h3> <b class="btn btn-warning btn-block">FREE</b><b>Referred By:</b> tlrtlr <br><b>Current BV:</b> L-0 | R-0 <br><b>Paid Member Below:</b> L-0 | R-0 <br><b>Free Member Below:</b> L-1 | R-2 <br></div></div>
</div></div>

</div>	


	
	





<!--================================================LEFT================================================-->





<!-- JS Global Compulsory -->
<script src="http://localhost/mlm2/member/assets/plugins/jquery/jquery.min.js"></script>
<script src="http://localhost/mlm2/member/assets/plugins/jquery/jquery-migrate.min.js"></script>
<script src="http://localhost/mlm2/member/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script src="http://localhost/mlm2/member/assets/plugins/back-to-top.js"></script>
<script src="http://localhost/mlm2/member/assets/plugins/smoothScroll.js"></script>
<script src="http://localhost/mlm2/member/assets/plugins/sky-forms-pro/skyforms/js/jquery.validate.min.js"></script>
<script src="http://localhost/mlm2/member/assets/plugins/scrollbar/js/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- JS Customization -->
<script src="http://localhost/mlm2/member/assets/js/custom.js"></script>
<!-- JS Page Level -->
<script src="http://localhost/mlm2/member/assets/js/shop.app.js"></script>
<script src="http://localhost/mlm2/member/assets/js/plugins/style-switcher.js"></script>
<script src="http://localhost/mlm2/member/assets/js/forms/page_registration.js"></script>


	<script>
		jQuery(document).ready(function() {
			App.init();
			App.initScrollBar();
			Registration.initRegistration();
			StyleSwitcher.initStyleSwitcher();
		});
	</script>



<script type='text/javascript'>

	
$('.user').each(function() {
    var $this = $(this);
    $this.popover({
      trigger: 'click',
      placement: 'bottom',
      html: true,
      content: $this.find('.userInfo').html()  
    });
});


</script>































































	
</div>
<!--==================SECOND==================-->





</div>













</div><!--/end row-->
</div><!--/end container-->
</div>
<!--=== End Registre ===-->