
<!--=== Registre ===-->
<div style="margin-top:30px;">
<div class="container col-md-12">
<div class="row">


<div class="col-md-12">


<!-- BEGIN EXAMPLE TABLE PORTLET-->
<div class="portlet light bordered">
<div class="portlet-title">
<div class="caption font-dark">
<span class="caption-subject bold uppercase"> Binary Commission</span>
</div>
<div class="tool"> </div>
</div>
<div class="portlet-body">
<table class="table table-striped table-bordered table-hover" id="sample_1">
<thead>



<tr>
<th> SL# </th>
<th> Amount </th>
<th> Description </th>
<th> Time </th>
</tr>

</thead><tbody>

                                
<tr>

<td>0001</td>
<td><b class='btn btn-success btn-xs'> 1 EUR </b></td>
<td>Matching Bonus Of 1 Users</td>
<td>2016-12-31 03:24:48</td>






</tr>                                            

</tbody>
</table>
</div>
</div>
<!-- END EXAMPLE TABLE PORTLET-->

</div>


<div style="margin-top:100px;"></div>




</div><!--/end row-->
</div><!--/end container-->
</div>
<!--=== End Registre ===-->
